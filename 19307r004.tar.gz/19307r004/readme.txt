No extra parameters needed.
